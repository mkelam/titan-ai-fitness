import React, { useState } from 'react';
import { View } from './types';
import { LoginView, GoalsView, ExperienceView } from './views/Onboarding';
import { DashboardView } from './views/Dashboard';
import { TrainingLogView, FormCheckView } from './views/Training';
import { SkillTreeView, TeamHubView } from './views/Gamification';
import { BottomNav } from './components/UI';

const App: React.FC = () => {
  const [currentView, setView] = useState<View>(View.LOGIN);

  const renderView = () => {
    switch (currentView) {
      case View.LOGIN: return <LoginView setView={setView} />;
      case View.ONBOARDING_GOALS: return <GoalsView setView={setView} />;
      case View.ONBOARDING_EXP: return <ExperienceView setView={setView} />;
      
      case View.DASHBOARD: return <DashboardView setView={setView} />;
      
      case View.TRAINING_LOG: return <TrainingLogView setView={setView} />;
      case View.AI_FORM_CHECK: return <FormCheckView setView={setView} />;
      
      case View.SKILL_TREE: return <SkillTreeView setView={setView} />;
      case View.TEAM_HUB: return <TeamHubView setView={setView} />;
      
      // Mocks for other views to prevent crashes in MVP
      default: return (
        <div className="h-full flex flex-col items-center justify-center p-6 text-center">
          <span className="material-symbols-rounded text-6xl text-gray-600 mb-4">construction</span>
          <h2 className="text-xl font-bold mb-2">Work in Progress</h2>
          <p className="text-gray-400 mb-6">The {currentView} module is being forged in the Titan fires.</p>
          <button onClick={() => setView(View.DASHBOARD)} className="text-neon underline">Return to Dashboard</button>
        </div>
      );
    }
  };

  return (
    <div className="w-full h-screen bg-black text-white font-sans overflow-hidden flex flex-col">
      <main className="flex-1 relative overflow-hidden">
        {renderView()}
      </main>
      <BottomNav currentView={currentView} setView={setView} />
    </div>
  );
};

export default App;
