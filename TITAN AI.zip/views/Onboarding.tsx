import React, { useState } from 'react';
import { View } from '../types';
import { Button, GlassCard } from '../components/UI';

export const LoginView: React.FC<{ setView: (v: View) => void }> = ({ setView }) => (
  <div className="flex flex-col h-full justify-center p-6 bg-[url('https://picsum.photos/800/1200?grayscale')] bg-cover bg-center relative">
    <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
    <div className="relative z-10 flex flex-col gap-6">
      <div className="text-center mb-8">
        <h1 className="text-5xl font-bold mb-2 tracking-tighter text-white">TITAN</h1>
        <p className="text-gray-400 uppercase tracking-widest text-sm">Forge Your Legacy</p>
      </div>
      
      <GlassCard>
        <h2 className="text-xl font-bold mb-4">Initialize System</h2>
        <input type="email" placeholder="Identity (Email)" className="w-full bg-white/5 border border-white/10 rounded-lg p-3 mb-3 text-white focus:border-neon outline-none" />
        <input type="password" placeholder="Passkey" className="w-full bg-white/5 border border-white/10 rounded-lg p-3 mb-6 text-white focus:border-neon outline-none" />
        <Button fullWidth onClick={() => setView(View.ONBOARDING_GOALS)}>ENTER THE ARENA</Button>
        <div className="mt-4 text-center text-sm text-gray-400">
          <span className="block mb-2">Or sync via</span>
          <div className="flex justify-center gap-4">
            <button className="p-2 bg-white/10 rounded-full hover:bg-white/20"><span className="material-symbols-rounded">check_circle</span></button>
            <button className="p-2 bg-white/10 rounded-full hover:bg-white/20"><span className="material-symbols-rounded">stars</span></button>
          </div>
        </div>
      </GlassCard>
    </div>
  </div>
);

export const GoalsView: React.FC<{ setView: (v: View) => void }> = ({ setView }) => {
  const [selected, setSelected] = useState<string | null>(null);
  
  const goals = [
    { id: 'str', icon: 'fitness_center', title: 'Titan Strength', desc: 'Max power & hypertrophy' },
    { id: 'cut', icon: 'local_fire_department', title: 'Shredded', desc: 'Fat loss & definition' },
    { id: 'perf', icon: 'bolt', title: 'Performance', desc: 'Agility & Endurance' },
  ];

  return (
    <div className="flex flex-col h-full p-6 pt-12 relative">
      <div className="absolute inset-0 z-[-1] bg-gradient-to-b from-green-900/20 to-black" />
      <h2 className="text-3xl font-bold mb-2">Choose Your Path</h2>
      <p className="text-gray-400 mb-8">This defines your skill tree.</p>
      
      <div className="flex flex-col gap-4 flex-1">
        {goals.map(g => (
          <GlassCard 
            key={g.id} 
            className={`cursor-pointer border transition-all ${selected === g.id ? 'border-neon bg-neon/10' : 'border-transparent'}`}
            onClick={() => setSelected(g.id)}
          >
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-full ${selected === g.id ? 'bg-neon text-black' : 'bg-white/10 text-white'}`}>
                <span className="material-symbols-rounded">{g.icon}</span>
              </div>
              <div>
                <h3 className="font-bold text-lg">{g.title}</h3>
                <p className="text-sm text-gray-400">{g.desc}</p>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>
      
      <Button 
        fullWidth 
        className="mt-6"
        variant={selected ? 'primary' : 'secondary'}
        onClick={() => selected && setView(View.ONBOARDING_EXP)}
      >
        CONFIRM PROTOCOL
      </Button>
    </div>
  );
};

export const ExperienceView: React.FC<{ setView: (v: View) => void }> = ({ setView }) => (
  <div className="flex flex-col h-full p-6 pt-12">
    <h2 className="text-3xl font-bold mb-2">Calibration</h2>
    <p className="text-gray-400 mb-8">AI requires your baseline data.</p>
    
    <div className="flex-1 flex flex-col gap-6">
      <div>
        <label className="text-sm text-gray-400 uppercase font-bold">Lifting Experience</label>
        <input type="range" min="0" max="10" className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer mt-4 accent-neon" />
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>Rookie</span>
          <span>Veteran</span>
          <span>Titan</span>
        </div>
      </div>
      
      <div>
        <label className="text-sm text-gray-400 uppercase font-bold">AI Coach Personality</label>
        <div className="grid grid-cols-3 gap-2 mt-2">
          {['Sage', 'Sergeant', 'Hype'].map(p => (
            <button key={p} className="p-3 rounded-xl border border-white/10 hover:border-neon hover:bg-neon/5 text-sm font-medium transition-all">
              {p}
            </button>
          ))}
        </div>
      </div>
    </div>

    <Button fullWidth onClick={() => setView(View.DASHBOARD)}>INITIALIZE</Button>
  </div>
);
