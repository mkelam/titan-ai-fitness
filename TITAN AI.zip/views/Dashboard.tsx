import React from 'react';
import { View } from '../types';
import { GlassCard } from '../components/UI';

export const DashboardView: React.FC<{ setView: (v: View) => void }> = ({ setView }) => {
  return (
    <div className="h-full overflow-y-auto pb-24">
      {/* Hero Section - Character Sheet */}
      <div className="relative p-6 pt-12 pb-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-green-900/30 to-black z-[-1]" />
        <div className="flex justify-between items-start mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="material-symbols-rounded text-neon text-sm">verified</span>
              <span className="text-xs font-bold text-neon tracking-widest uppercase">Rank 12</span>
            </div>
            <h1 className="text-3xl font-bold">Alexios</h1>
            <p className="text-gray-400 text-sm">Iron Lifter • Level 14</p>
          </div>
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-2 border-neon p-1">
              <img src="https://picsum.photos/100/100" className="w-full h-full rounded-full object-cover grayscale" alt="Avatar" />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-black/80 text-neon text-xs px-2 py-1 rounded-full border border-neon/30">
              ⚡ 94
            </div>
          </div>
        </div>

        {/* Buffs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          <div className="flex items-center gap-1 bg-white/5 px-3 py-1 rounded-full border border-white/10 text-xs">
            <span className="material-symbols-rounded text-yellow-400 text-sm">bolt</span>
            <span>+10% STR</span>
          </div>
          <div className="flex items-center gap-1 bg-white/5 px-3 py-1 rounded-full border border-white/10 text-xs">
            <span className="material-symbols-rounded text-blue-400 text-sm">water_drop</span>
            <span>Hydrated</span>
          </div>
        </div>

        {/* Coach Nudge */}
        <GlassCard className="bg-gradient-to-br from-green-900/40 to-black border-l-4 border-l-neon" onClick={() => setView(View.AI_COACH_CHAT)}>
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center shrink-0">
              <span className="material-symbols-rounded text-neon">smart_toy</span>
            </div>
            <div>
              <h3 className="font-bold text-sm text-neon mb-1">COACH NUDGE</h3>
              <p className="text-sm text-gray-200">"Recovery detected. Your HRV is high. Ready for a 10-min mobility reset to maximize gains?"</p>
              <div className="mt-3 flex gap-2">
                <button className="bg-neon text-black text-xs font-bold px-4 py-2 rounded-lg">START SESSION</button>
              </div>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Quick Actions Grid */}
      <div className="px-6 mb-8">
        <h2 className="text-sm font-bold text-gray-500 uppercase mb-4 tracking-wider">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-4">
          <GlassCard className="flex flex-col items-center justify-center gap-2 py-6 active:bg-white/5" onClick={() => setView(View.TRAINING_LOG)}>
            <span className="material-symbols-rounded text-3xl text-white">fitness_center</span>
            <span className="text-sm font-medium">Training</span>
          </GlassCard>
          <GlassCard className="flex flex-col items-center justify-center gap-2 py-6 active:bg-white/5" onClick={() => setView(View.NUTRITION_LOG)}>
            <span className="material-symbols-rounded text-3xl text-white">restaurant</span>
            <span className="text-sm font-medium">Nutrition</span>
          </GlassCard>
          <GlassCard className="flex flex-col items-center justify-center gap-2 py-6 active:bg-white/5" onClick={() => setView(View.PROGRESS_CHECKIN)}>
            <span className="material-symbols-rounded text-3xl text-white">photo_camera</span>
            <span className="text-sm font-medium">Check-in</span>
          </GlassCard>
          <GlassCard className="flex flex-col items-center justify-center gap-2 py-6 active:bg-white/5" onClick={() => setView(View.SKILL_TREE)}>
            <span className="material-symbols-rounded text-3xl text-white">hub</span>
            <span className="text-sm font-medium">Skills</span>
          </GlassCard>
        </div>
      </div>

      {/* Streak */}
      <div className="px-6">
        <GlassCard onClick={() => setView(View.STREAK_CALENDAR)}>
          <div className="flex justify-between items-center">
            <div className="flex gap-3 items-center">
              <span className="material-symbols-rounded text-orange-500 text-3xl">local_fire_department</span>
              <div>
                <h3 className="font-bold text-lg">14 Day Streak</h3>
                <p className="text-xs text-gray-400">Keep the fire burning</p>
              </div>
            </div>
            <span className="material-symbols-rounded text-gray-500">chevron_right</span>
          </div>
          {/* Heatmap mini */}
          <div className="flex gap-1 mt-4 justify-between opacity-50">
            {[1,1,1,1,0,1,1].map((a, i) => (
              <div key={i} className={`h-2 flex-1 rounded-full ${a ? 'bg-orange-500' : 'bg-gray-700'}`} />
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
