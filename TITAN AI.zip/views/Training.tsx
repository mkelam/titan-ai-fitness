import React, { useState } from 'react';
import { View } from '../types';
import { Header, GlassCard, Button } from '../components/UI';

export const TrainingLogView: React.FC<{ setView: (v: View) => void }> = ({ setView }) => (
  <div className="h-full flex flex-col">
    <Header title="Training Log" leftIcon="arrow_back" onLeftClick={() => setView(View.DASHBOARD)} rightIcon="calendar_today" />
    
    <div className="flex-1 overflow-y-auto p-4 pb-24">
      {/* Date Header */}
      <div className="flex justify-between items-end mb-6 px-2">
        <div>
          <h2 className="text-3xl font-bold">Wednesday</h2>
          <p className="text-gray-400">Oct 24 • Leg Day</p>
        </div>
        <div className="text-neon font-bold text-sm bg-neon/10 px-3 py-1 rounded-full">
          Active Quest
        </div>
      </div>

      {/* Quest Context */}
      <div className="mb-6">
        <GlassCard className="border-neon/30 bg-neon/5">
          <div className="flex items-center gap-3 mb-2">
            <span className="material-symbols-rounded text-neon">swords</span>
            <span className="font-bold text-sm uppercase text-neon">Daily Quest</span>
          </div>
          <p className="text-sm font-medium">"Leg Day Destruction": Complete 3 sets of Squats.</p>
          <div className="w-full bg-black/50 h-1.5 rounded-full mt-3 overflow-hidden">
            <div className="bg-neon w-1/3 h-full" />
          </div>
        </GlassCard>
      </div>

      {/* Exercises */}
      <div className="flex flex-col gap-4">
        {[
          { name: 'Barbell Back Squat', sets: '3', reps: '8-10', weight: '100kg' },
          { name: 'Leg Press', sets: '3', reps: '12', weight: '240kg' },
          { name: 'Romanian Deadlift', sets: '3', reps: '10', weight: '80kg' }
        ].map((ex, i) => (
          <GlassCard key={i}>
            <div className="flex justify-between mb-4">
              <h3 className="font-bold text-lg">{ex.name}</h3>
              <button className="text-gray-400"><span className="material-symbols-rounded">more_horiz</span></button>
            </div>
            
            {/* Sets */}
            <div className="flex flex-col gap-2">
              <div className="grid grid-cols-4 gap-2 text-xs text-gray-500 uppercase font-bold text-center mb-1">
                <span>Set</span>
                <span>Kg</span>
                <span>Reps</span>
                <span>Check</span>
              </div>
              {[1, 2, 3].map(set => (
                <div key={set} className="grid grid-cols-4 gap-2 items-center">
                  <div className="bg-white/5 rounded p-2 text-center text-sm font-mono text-gray-400">{set}</div>
                  <input type="number" defaultValue={parseInt(ex.weight)} className="bg-white/10 rounded p-2 text-center text-white font-bold" />
                  <input type="number" defaultValue={8} className="bg-white/10 rounded p-2 text-center text-white font-bold" />
                  <button className={`p-2 rounded flex items-center justify-center ${set === 1 ? 'bg-neon text-black' : 'bg-white/5 text-gray-500'}`}>
                    <span className="material-symbols-rounded text-lg">check</span>
                  </button>
                </div>
              ))}
            </div>
            <div className="mt-4 flex justify-end gap-2">
               <button onClick={() => setView(View.AI_FORM_CHECK)} className="text-xs flex items-center gap-1 text-neon border border-neon/30 px-3 py-1 rounded-full">
                 <span className="material-symbols-rounded text-sm">videocam</span> AI Form Check
               </button>
            </div>
          </GlassCard>
        ))}
        
        <Button variant="secondary" className="mt-4">+ Add Exercise</Button>
      </div>
    </div>
    
    <div className="p-4 bg-black/80 backdrop-blur-md border-t border-white/10">
      <Button fullWidth onClick={() => setView(View.PERSONAL_BEST)}>FINISH WORKOUT</Button>
    </div>
  </div>
);

export const FormCheckView: React.FC<{ setView: (v: View) => void }> = ({ setView }) => (
  <div className="h-full flex flex-col bg-black">
    <Header title="AI Form Check" leftIcon="close" onLeftClick={() => setView(View.TRAINING_LOG)} />
    <div className="flex-1 relative">
      <img src="https://picsum.photos/400/600" className="w-full h-full object-cover opacity-60" alt="Camera Feed" />
      
      {/* Overlay UI */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="w-64 h-96 border-2 border-neon/50 rounded-3xl relative">
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-neon -mt-1 -ml-1"></div>
          <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-neon -mt-1 -mr-1"></div>
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-neon -mb-1 -ml-1"></div>
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-neon -mb-1 -mr-1"></div>
          
          {/* Skeleton Overlay Mock */}
          <div className="absolute inset-0 flex items-center justify-center opacity-50">
             <svg width="200" height="300" viewBox="0 0 200 300" fill="none" stroke="#00ff9d" strokeWidth="2">
               <circle cx="100" cy="50" r="15" />
               <line x1="100" y1="65" x2="100" y2="150" />
               <line x1="100" y1="80" x2="60" y2="120" />
               <line x1="100" y1="80" x2="140" y2="120" />
               <line x1="100" y1="150" x2="70" y2="250" />
               <line x1="100" y1="150" x2="130" y2="250" />
             </svg>
          </div>
        </div>
        <div className="mt-8 bg-black/60 backdrop-blur-md px-6 py-2 rounded-full border border-white/10 text-neon font-mono">
          DEPTH: OPTIMAL
        </div>
      </div>
    </div>
    <div className="p-6 bg-black/80 flex justify-center gap-6">
      <button className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center">
        <div className="w-12 h-12 bg-red-500 rounded-full"></div>
      </button>
    </div>
  </div>
);
